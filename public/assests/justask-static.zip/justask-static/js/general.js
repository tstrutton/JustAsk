 var logo = document.querySelector('#logo');
 var logoutbtn = document.querySelector('#logoutbtn');

function mediaQueries(){
	if(window.innerWidth >=1440){
		logo.src = 'images/logo.svg';
		logoutbtn.innerHTML = 'Logout';
	}
}

mediaQueries();

var activateActive = document.querySelector('#activateActive');
var activate = document.querySelector('#activate');

activate.addEventListener('click', function(){
	
});
